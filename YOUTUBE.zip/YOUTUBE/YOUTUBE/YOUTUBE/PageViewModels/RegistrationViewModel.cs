﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using YOUTUBE.Models;
using YOUTUBE.Services;

namespace YOUTUBE.PageViewModels
{
    public class RegistrationViewModel : BaseViewModel
    {
        public RegistrationModel _registrationModel { get; set; }
        DataAccess _dataAccess;
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
        public RegistrationViewModel()
        {
            _dataAccess = new DataAccess();


        }

        public int SaveUserData(RegistrationModel regModel)
        {
            int val = 0;
            try
            {
                val = _dataAccess.SaveRegistrationModel(regModel);

            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());

            }
            return val;
        }
        public List<RegistrationModel> GetUserData()
        {
            List<RegistrationModel> val = null;
            try
            {
                val = _dataAccess.GetAllRegistrationModels();

            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());

            }
            return val;
        }
        public int Delete(RegistrationModel regModel)
        {
            int val = 0;
            try
            {
                val = _dataAccess.DeleteRegistrationModel(regModel);

            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());

            }
            return val;
        }
        public int Edit(RegistrationModel regModel)
        {
            int val = 0;
            try
            {
                val = _dataAccess.EditRegistrationModel(regModel);

            }

            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());

            }
            return val;
        }
    }
}
