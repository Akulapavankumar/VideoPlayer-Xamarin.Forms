﻿using System;
using System.Collections.Generic;
using System.Text;
using YOUTUBE.Services;

namespace YOUTUBE.PageViewModels
{
    public class BaseViewModel
    {
        DataAccess _database;
        public BaseViewModel()
        {
            _database = new DataAccess();
        }
    }
}
