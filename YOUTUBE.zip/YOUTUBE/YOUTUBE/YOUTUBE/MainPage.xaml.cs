﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using YOUTUBE.Models;
using YOUTUBE.Pages;
namespace YOUTUBE
{
    //public partial class MainPage : MasterDetailPage
    //{
    //    public MainPage()
    //    {
    //        InitializeComponent();
    //        Detail = new NavigationPage(new YouTubePage());
    //        IsPresented = false;
    //    }
    //    private void OnLabelTappedHome(object sender, EventArgs args) 
    //    {
    //        Detail = new NavigationPage(new YouTubePage());
    //        IsPresented = false;
    //    }
    //    private void OnLabelTappedForgot_Clicked(object sender, EventArgs args)
    //    {
    //        Detail = new NavigationPage(new ForgotPassword());
    //        IsPresented = false;
    //    }
    //    private void OnLabelTappedLogin(object sender, EventArgs args)
    //    {
    //        Detail = new NavigationPage(new LoginPage());
    //        IsPresented = false;
    //    }
    //    private void OnLabelTappedRegistration(object sender, EventArgs args)
    //    {
    //        Detail = new NavigationPage(new RegistrationPage());
    //        IsPresented = false;
    //    }



    //}

    public partial class MainPage : MasterDetailPage
    {
        public List<MasterPageItem> menuList { get; set; }
        public MainPage()
        {
            InitializeComponent();
            menuList = new List<MasterPageItem>();
            menuList.Add(new MasterPageItem() { Title = "Home", Icon = "Home.jpg", TargetType = typeof(YouTubePage) });
            menuList.Add(new MasterPageItem() { Title = "Registration", Icon = "Register.png", TargetType = typeof(RegistrationPage) });
            menuList.Add(new MasterPageItem() { Title = "Login", Icon = "Login.jpg", TargetType = typeof(LoginPage) });
            menuList.Add(new MasterPageItem() { Title = "Fogotpassword?", Icon = "Fogotpassword.jpg", TargetType = typeof(ForgotPassword) });
            menuList.Add(new MasterPageItem() { Title = "Users", Icon = "user.png", TargetType = typeof(DisplayPage) });
            menuList.Add(new MasterPageItem() { Title = "Logout", Icon = "Logout.jpg", TargetType = typeof(LoginPage) });
                       
            navigationList.ItemsSource = menuList; 
                      
            Detail = new NavigationPage((Page)Activator.CreateInstance(typeof(LoginPage)));
        }
              
        private void OnMenuItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            var item = (MasterPageItem)e.SelectedItem;
            Type page = item.TargetType;

            Detail = new NavigationPage((Page)Activator.CreateInstance(page));
            IsPresented = false;
           
        }
    }
}
