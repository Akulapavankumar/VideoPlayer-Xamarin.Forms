﻿using SQLite.Net.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace YOUTUBE.Models
{
    public class RegistrationModel
    {
        [PrimaryKey, AutoIncrement]
        public int id { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string DateOfBirth { get; set; }
        public string Gender { get; set; }
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
