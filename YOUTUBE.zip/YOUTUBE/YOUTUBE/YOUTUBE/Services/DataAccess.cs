﻿using SQLite.Net;
using System.Collections.Generic;
using Xamarin.Forms;
using YOUTUBE.Models;

namespace YOUTUBE.Services
{
    public class DataAccess
    {
        SQLiteConnection dbConn;
        public DataAccess()
        {
            dbConn = DependencyService.Get<ISQLite>().GetConnection();
            dbConn.CreateTable<RegistrationModel>();
        }

        public List<RegistrationModel> GetAllRegistrationModels()
        {
            return dbConn.Query<RegistrationModel>("Select * From [RegistrationModel]");

        }
        public int SaveRegistrationModel(RegistrationModel aRegistrationModel)
        {
            return dbConn.Insert(aRegistrationModel);
        }
        public int DeleteRegistrationModel(RegistrationModel aRegistrationModel)
        {
            return dbConn.Delete(aRegistrationModel);
        }
        public int EditRegistrationModel(RegistrationModel aRegistrationModel)
        {
            return dbConn.Update(aRegistrationModel);
        }
    }
}
