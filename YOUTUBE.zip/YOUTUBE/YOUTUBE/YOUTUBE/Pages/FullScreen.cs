﻿using Xamarin.Forms;

namespace YOUTUBE.Pages
{
    internal class FullScreen : Page
    {
    }
}