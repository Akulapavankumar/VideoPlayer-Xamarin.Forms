﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using YOUTUBE.PageViewModels;

namespace YOUTUBE.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : CarouselPage
    {
        public RegistrationViewModel _registrationViewModel;
        public LoginPage()
        {
            InitializeComponent();
            _registrationViewModel = new RegistrationViewModel();
        }
        //private async void Forgot_Clicked(object s, EventArgs e)
        //{
        //    await Navigation.PushAsync(new ForgotPassword());

        //}
        public async void OnLabelTappedForgot_Clicked(object sender, EventArgs args) 
        {
            await Navigation.PushAsync(new ForgotPassword());
        }
        private async void Reg_Clicked(object s, EventArgs e)
        {
            await Navigation.PushAsync(new RegistrationPage());
        }

        private async void Login_Clicked(object s, EventArgs e)
        {
            if (Validate())
            {
                // complete Registration process

                try
                {
                    var res = _registrationViewModel.GetUserData();

                    //string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "user.db3"); //Call Database  
                    //var db = new GetConnection(dpPath);
                    //var data = db.Table<RegistrationModel>(); //Call Table  
                    var data1 = res.Where(x => x.EmailAddress == usernameEntry.Text && x.Password == passwordEntry.Text).FirstOrDefault(); //Linq Query  
                    if (data1 != null)
                    {
                        await DisplayAlert("Login", "Success", "Ok");
                        await Navigation.PushAsync(new YouTubePage());
                    }
                    else
                    {
                        await DisplayAlert("Login", "Username and Password is rong!", "Ok");
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.ToString());
                }

            }
        }
        private bool Validate()
        {
            var Email = usernameEntry.Text;
            var Password = passwordEntry.Text;

            var res = _registrationViewModel.GetUserData();

            if (string.IsNullOrEmpty(usernameEntry.Text))
            {
                DisplayAlert("User", "Please enter Email Address", "OK");
                usernameEntry.Focus();
                return false;
            }
            if (Email != null)
            {
                var data1 = res.Where(x => x.EmailAddress == usernameEntry.Text).FirstOrDefault(); //Linq Query  
                if (data1 == null)
                {
                    DisplayAlert("User", "Please enter a valid Email Address", "OK");
                    usernameEntry.Focus();
                    return false;
                }
            }


            if (string.IsNullOrEmpty(passwordEntry.Text))
            {
                DisplayAlert("User", "Please enter Password", "OK");
                passwordEntry.Focus();
                return false;
            }
            if (Email != null)
            {
                var data1 = res.Where(x => x.Password == passwordEntry.Text).FirstOrDefault(); //Linq Query  
                if (data1 == null)
                {
                    DisplayAlert("User", "Please enter a valid password", "OK");
                    passwordEntry.Focus();
                    return false;
                }
            }


            return true;
        }
    }
}