﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace YOUTUBE.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class DisplayPage : ContentPage
	{
		public DisplayPage ()
		{
			InitializeComponent ();
            OnAppearing();
            MyListView.ItemSelected += (object sender, SelectedItemChangedEventArgs e) =>
            {
                var Alert = e.SelectedItem as Post;
                DisplayAlert( "User Body", Alert.Body, "cancel", "Ok");
            };
        }

       

        internal class Post
        {
            public int Id { get; set; }
            public string Title { get; set; }
            public string Body { get; set; }
            public int UserId { get; set; }           

        }
        private const string Url = "http://jsonplaceholder.typicode.com/posts";
        //private const string Url = "https://ssgsemsconsultingservice.azurewebsites.net/api/GetConsultants?code=qsebUOlYl9Xxh/aaB8No7yAOLpEWMAKwvEOzekepP0bKRNuntJpAiA==";
        private readonly HttpClient _client = new HttpClient();
        private ObservableCollection<Post> _posts;

        private async void OnAppearing()
        {
            string content = await _client.GetStringAsync(Url); //Sends a GET request to the specified Uri and returns the response body as a string in an asynchronous operation
            List<Post> posts = JsonConvert.DeserializeObject<List<Post>>(content); //Deserializes or converts JSON String into a collection of Post
            _posts = new ObservableCollection<Post>(posts); //Converting the List to ObservalbleCollection of Post
            MyListView.ItemsSource = _posts; //Assigning the ObservableCollection to MyListView in the XAML of this file

        }
    }
}