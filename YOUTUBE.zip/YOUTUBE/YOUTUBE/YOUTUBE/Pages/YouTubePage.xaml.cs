﻿using Newtonsoft.Json;
using Plugin.Connectivity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using YOUTUBE.Models;

namespace YOUTUBE.Pages
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class YouTubePage : ContentPage
	{
        public YouTubePage()
        { 
            InitializeComponent();
            progressControl.Focus();
            progressControl.IsVisible = false;
            if (CrossConnectivity.Current.IsConnected)
            {
                progressControl.IsVisible = true;
                GetChannelDataNull();

                MyList.ItemsSource = Items;
            }
            else
            {
                DisplayAlert("User", "No Internet", "Ok");
            }
           
           
        }
        private bool OnTimer()
        {
            var progress = (progressControl.Progress + .01);
            if (progress > 1) progress = 0;
            progressControl.Progress = progress;
            return true;
        }

        public async void PlayVideo(object sender, SelectedItemChangedEventArgs e)
        {
            var video = e.SelectedItem as YouTubeItem;
           // Navigation.PushAsync(new VideoPage(video.VideoId));
            await Navigation.PushAsync(new VideoPage(video.VideoId));
            // Navigation.PushAsync(new WebViewPage(video.VideoId));
            //if (video.VideoId != null)
            //{
            //    Device.OpenUri(new Uri("https://www.youtube.com/watch?v=" + video.VideoId));
            //}
            //else
            //{
            //    DisplayAlert("Pavan","ID Is Null !", "ok");
            //}
        }

        private void SearchDataContent(object sender, EventArgs e)
        {
            string filter = searchBar.Text;
            if (string.IsNullOrEmpty(filter))
            {
                Xamarin.Forms.Device.StartTimer(TimeSpan.FromSeconds(.02), OnTimer);
                progressControl.IsVisible = true;
                GetChannelDataNull();
                MyList.ItemsSource = Items;
            }
            else
            {
                Xamarin.Forms.Device.StartTimer(TimeSpan.FromSeconds(.02), OnTimer);
                progressControl.IsVisible = true;
                GetChannelData();
                MyList.ItemsSource = Items;
                {
                    GetChannelData();
                    MyList.ItemsSource = Items;
                }

            }

        }

        //const string ChannelId = "UCU_If3OQp9FPHoP1BteFNlA";

        //  string channelUrl = $"https://www.googleapis.com/youtube/v3/search?part=id&maxResults=20&channelId={ChannelId}&key={ApiKey}";

        private List<YouTubeItem> Items { get; set; } = new List<YouTubeItem>();
        private List<YouTubeItem> VideoId { get; set; } = new List<YouTubeItem>();

        //public override void Init(object initData)
        //{
        //    base.Init(initData);

        //    // Retrieve our data.
        //    Task.Factory.StartNew(GetChannelData);
        //}

        private async Task GetChannelData()
        {
            if (CrossConnectivity.Current.IsConnected)
            {
                string filter = searchBar.Text;
            const string ApiKey = "AIzaSyB7cpaKiojWIKVz6rTYNRn_CiRI0GWt8q0";
            string channelUrl = $"https://www.googleapis.com/youtube/v3/search?part=snippet&q={filter}&maxResults=50&type=video&key={ApiKey}";
            try
            {

                using (var httpClient = new HttpClient())
                {
                    var videoIds = new List<string>();
                    var json = await httpClient.GetStringAsync(channelUrl);

                    //Deserialize our data, this is in a simple List format.
                    var response = JsonConvert.DeserializeObject<YouTubeApiListRoot>(json);

                    //Add all the video id's we've found to our list.
                    videoIds.AddRange(response.items.Select(item => item.id.videoId));

                    //Get the details for all our items.
                    Items = await GetVideoDetailsAsync(videoIds);
                    MyList.ItemsSource = Items;
                }
                progressControl.IsVisible = false;
            }
            catch (Exception ex)
            {
                var ms = ex;
            }
            }
            else
            {
                await DisplayAlert("User", "No Internet connection", "Ok");
            }
        }
        private async Task GetChannelDataNull()
        {
            if (CrossConnectivity.Current.IsConnected)
            {
                const string ApiKey = "AIzaSyB7cpaKiojWIKVz6rTYNRn_CiRI0GWt8q0";
            string channelUrl = $"https://www.googleapis.com/youtube/v3/search?part=snippet&q=(sysfore)&maxResults=50&type=video&key={ApiKey}";
            try
            {

                using (var httpClient = new HttpClient())
                {
                    var videoIds = new List<string>();
                    var json = await httpClient.GetStringAsync(channelUrl);

                    //Deserialize our data, this is in a simple List format.
                    var response = JsonConvert.DeserializeObject<YouTubeApiListRoot>(json);

                    //Add all the video id's we've found to our list.
                    videoIds.AddRange(response.items.Select(item => item.id.videoId));

                    //Get the details for all our items.
                    Items = await GetVideoDetailsAsync(videoIds);
                    MyList.ItemsSource = Items;
                }   
                progressControl.IsVisible = false;
            }
            catch (Exception ex)
            {
                var ms = ex;
            }
        }
            else
            {
                await DisplayAlert("User","No Internet connection", "Ok");
    }
}

        private async Task<List<YouTubeItem>> GetVideoDetailsAsync(List<string> videoIds)
        {
            const string ApiKey = "AIzaSyB7cpaKiojWIKVz6rTYNRn_CiRI0GWt8q0";
            string detailsUrl = "https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics&key=" + ApiKey + "&id={0}";
            try
            {
                var videoIdString = string.Join(",", videoIds);
                var youtubeItems = new List<YouTubeItem>();
                using (var httpClient = new HttpClient())
                {
                    var json = await httpClient.GetStringAsync(string.Format(detailsUrl, videoIdString));
                    var response = JsonConvert.DeserializeObject<YouTubeApiDetailsRoot>(json);

                    foreach (var item in response.items)
                    {
                        var youTubeItem = new YouTubeItem()
                        {
                            Title = item.snippet.title,
                            Description = item.snippet.description,
                            ChannelTitle = item.snippet.channelTitle,
                            // PublishedAt = item.snippet.publishedAt,
                            VideoId = item.id,
                            DefaultThumbnailUrl = item.snippet?.thumbnails?.@default?.url,
                            MediumThumbnailUrl = item.snippet?.thumbnails?.medium?.url,
                            HighThumbnailUrl = item.snippet?.thumbnails?.high?.url,
                            StandardThumbnailUrl = item.snippet?.thumbnails?.standard?.url,
                            MaxResThumbnailUrl = item.snippet?.thumbnails?.maxres?.url,
                            ViewCount = item.statistics?.viewCount,
                            LikeCount = item.statistics?.likeCount,
                            DislikeCount = item.statistics?.dislikeCount,
                            FavoriteCount = item.statistics?.favoriteCount,
                            CommentCount = item.statistics?.commentCount,
                            Tags = item.snippet?.tags
                        };

                        youtubeItems.Add(youTubeItem);
                    }
                }

                return youtubeItems;
            }
            catch (Exception ex)
            {
                var ms = ex;
                return new List<YouTubeItem>();
            }
        }
    }
}
