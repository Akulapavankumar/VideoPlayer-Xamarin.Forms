﻿using SQLite.Net;

namespace YOUTUBE
{
    public interface ISQLite
    {
        SQLiteConnection GetConnection();
    }
}
